/* 
 * Copyright (C) 2012 by Tracelytics, Inc.
 * All rights reserved.
 *
 * Use and distribution of this software is subject to the terms and
 * limitations contained in the file LICENSE, which is provided with
 * this software distribution.
 */
#include "ngx_http_oboe_filter_module.h"
#include <assert.h>

extern struct plugin_data_t plugin_data;
extern ngx_http_output_header_filter_pt ngx_http_next_header_filter;
extern ngx_http_output_body_filter_pt ngx_http_next_body_filter;

#if !defined(BUILD_OBOE_NGINX_0_5) && !defined(BUILD_OBOE_NGINX_0_6)
/* Modified from code in ngx_http_variables.c
 * Uses new features available only since Nginx 0.8.0. */
ngx_uint_t ngx_oboe_server_port(ngx_http_request_t *r)
{
    ngx_uint_t            port;
    struct sockaddr_in   *sin;
#if (NGX_HAVE_INET6)
    struct sockaddr_in6  *sin6;
#endif

    if (ngx_connection_local_sockaddr(r->connection, NULL, 0) != NGX_OK) {
        return 0;
    }

    switch (r->connection->local_sockaddr->sa_family) {

#if (NGX_HAVE_INET6)
    case AF_INET6:
        sin6 = (struct sockaddr_in6 *) r->connection->local_sockaddr;
        port = ntohs(sin6->sin6_port);
        break;
#endif

    default: /* AF_INET */
        sin = (struct sockaddr_in *) r->connection->local_sockaddr;
        port = ntohs(sin->sin_port);
        break;
    }

    return port;
}
#endif /* !defined(BUILD_OBOE_NGINX_0_5) && !defined(BUILD_OBOE_NGINX_0_6) */

/* helper function, extracts any header from header list */
ngx_table_elt_t *ngx_http_oboe_get_header(ngx_list_part_t *part, const char *item) {
     ngx_list_part_t *data = part->elts;
     unsigned i;

    for (i = 0;; i++) {
        if (i >= part->nelts) {
            if (part->next == NULL) {
                break;
            }

            part = part->next;
            data = part->elts;
            i = 0;
        }

        ngx_table_elt_t *hdr = (ngx_table_elt_t *)data + i;
        if (!ngx_strcasecmp((u_char *)hdr->key.data, (u_char *)item)) {
            return hdr;
        }
    }

    return NULL;
}

/* helper function for response callback: send response report */
static int ngx_http_oboe_filter_send_report(oboe_metadata_t *md,
                                            oboe_event_t *xte,
                                            ngx_http_request_t *r) {
    int result;
    int retval = -2; // -2 is a dummy value for assert at end

    (void)oboe_event_add_info(xte, "Layer", NGX_OBOE_MODULE_LAYER_NAME);
    (void)oboe_event_add_info(xte, "Label", "exit");

    // Webserver Spec
    // HTTP-Host
#ifdef BUILD_OBOE_NGINX_0_5 // fix for Hardy (nginx-0.5.33)
    if (r->headers_in.host_name_len > 0) {
        (void)oboe_event_add_info_binary(xte, "HTTP-Host", 
                                         (char*)r->headers_in.host->value.data,
                                         r->headers_in.host_name_len);
    }
#else // works on Lucid, Maverick, etc
    if (r->headers_in.server.len > 0) {
        (void)oboe_event_add_info_binary(xte, "HTTP-Host",
                                         (char*)r->headers_in.server.data,
                                         r->headers_in.server.len);
    }
#endif
    // URL
    if (r->uri.len > 0) {
        (void)oboe_event_add_info_binary(xte, "URL",
                                         (char*)r->uri.data, r->uri.len);
        // Request-URI was previous name, double sent to keep BC for now
        (void)oboe_event_add_info_binary(xte, "Request-URI",
                                         (char*)r->uri.data, r->uri.len);
    }
    // Method
    if (r->method_name.len > 0) {
        (void)oboe_event_add_info_binary(xte, "Method", (char*)r->method_name.data,
                                         r->method_name.len);
    }
    // Status
    (void)oboe_event_add_info_int64(xte, "Status", r->headers_out.status);
    // Proto
#if (NGX_HTTP_SSL)
    if (r->connection->ssl) {
        (void)oboe_event_add_info(xte, "Proto", "https");
    } else {
        (void)oboe_event_add_info(xte, "Proto", "http");
    }
#else
    (void)oboe_event_add_info(xte, "Proto", "http");
#endif
#if !defined(BUILD_OBOE_NGINX_0_5) && !defined(BUILD_OBOE_NGINX_0_6)
    // Port
    (void)oboe_event_add_info_int64(xte, "Port", ngx_oboe_server_port(r));
#endif /* !defined(BUILD_OBOE_NGINX_0_5) && !defined(BUILD_OBOE_NGINX_0_6) */

    // ClientIP
    if (r->connection->addr_text.len > 0) {
        (void)oboe_event_add_info_binary(xte, "ClientIP",
                                         (char*)r->connection->addr_text.data, r->connection->addr_text.len);
    }

    // From incoming headers:
    // Forwarded-Host
    // Forwarded-Proto
    // Forwarded-Port
    // Request-Orig-URI
    ngx_table_elt_t *forwarded_for = ngx_http_oboe_get_header(&r->headers_in.headers.part, "X-Forwarded-For");
    ngx_table_elt_t *forwarded_host = ngx_http_oboe_get_header(&r->headers_in.headers.part, "X-Forwarded-Host");
    ngx_table_elt_t *forwarded_proto = ngx_http_oboe_get_header(&r->headers_in.headers.part, "X-Forwarded-Proto");
    ngx_table_elt_t *forwarded_port = ngx_http_oboe_get_header(&r->headers_in.headers.part, "X-Forwarded-Port");

    if (forwarded_for) {
        (void)oboe_event_add_info_binary(xte, "Forwarded-For",
                                         (const char *)forwarded_for->value.data,
                                         forwarded_for->value.len);
    }

    if (forwarded_host) {
        (void)oboe_event_add_info_binary(xte, "Forwarded-Host",
                                         (const char *)forwarded_host->value.data,
                                         forwarded_host->value.len);
    }

    if (forwarded_proto) {
        (void)oboe_event_add_info_binary(xte, "Forwarded-Proto",
                                         (const char *)forwarded_proto->value.data,
                                         forwarded_proto->value.len);
    }

    if (forwarded_port) {
        (void)oboe_event_add_info_binary(xte, "Forwarded-Port",
                                         (const char *)forwarded_port->value.data,
                                         forwarded_port->value.len);
    }

    if (r->unparsed_uri.len > 0) {
        (void)oboe_event_add_info_binary(xte, "Request-Orig-URI",
                                         (char*)r->unparsed_uri.data,
                                         r->unparsed_uri.len);
    }

    // nginx additional items
    // Remote-URI (copy of URL) above
    // Request-Line
    // Content-Length
    if (r->connection->addr_text.len > 0) {
        (void)oboe_event_add_info_binary(xte, "Remote-Host",
                                         (char*)r->connection->addr_text.data,
                                         r->connection->addr_text.len);
    }
    if (r->request_line.len > 0) {
        (void)oboe_event_add_info_binary(xte, "Request-Line",
                                         (char*)r->request_line.data,
                                         r->request_line.len);
    }
    (void)oboe_event_add_info_int64(xte, "Content-Length", r->headers_out.content_length_n);

    assert(plugin_data.reporter.send);

    result = oboe_reporter_send(&plugin_data.reporter, md, xte);
    if (result < 0) {
         ngx_log_error(NGX_LOG_WARN, r->connection->log, 0, "[ngx_http_oboe] reporter exit send failed");
        retval = -1;
        goto end;
    } else {
        ngx_log_debug0(NGX_LOG_DEBUG_HTTP, r->connection->log, 0, "[ngx_http_oboe] exit trace successfully sent");
    }

    retval = 0;

end:
    assert(retval == 0 || retval == -1);
    return retval;
}

/* header response callback, invoked before headers written */
ngx_int_t ngx_http_oboe_header_filter(ngx_http_request_t *r) {
    plugin_config *conf;
    handler_ctx *hctx = NULL;
    ngx_table_elt_t *out_xtrace;
    int result;

    conf = ngx_http_get_module_loc_conf(r, ngx_http_oboe_filter_module);
    assert(conf);

    // 1. bail out if this reponse isn't to be traced
    hctx = ngx_http_oboe_get_ctx(r);
    if (!hctx) {
        goto end;
    }

    // 2. save event, metadata in context
    if (!(oboe_metadata_is_valid(&hctx->md))) {
        ngx_log_debug0(NGX_LOG_DEBUG_HTTP, r->connection->log, 0, "[ngx_http_oboe] metadata is not valid, cannot save to context");
        goto end;
    }
    
    result = oboe_metadata_create_event(&hctx->md, &hctx->xte);
    if (result < 0) {
        ngx_log_error(NGX_LOG_WARN, r->connection->log, 0, "[ngx_http_oboe] creating event failed");
        goto end;
    }

    // guarantee that the body filter is invoked if and only if the event
    // is allocated
    hctx->event_set = 1;

    out_xtrace = ngx_http_oboe_get_xtrace(&r->headers_out.headers.part);
    if (out_xtrace) {
        result = oboe_event_add_edge_fromstr(&hctx->xte,
                                             (const char *)
                                             out_xtrace->value.data,
                                             out_xtrace->value.len);
        if (result < 0) {
            ngx_log_debug0(NGX_LOG_WARN, r->connection->log, 0, "[ngx_http_oboe] adding edge from string failed");
            goto end;
        }
    }


    // 3. set upstream output header to use new op_id

    // need to extract metadata from event, a job typically done by
    // reporter_send, which needs to be postponed
    result = ngx_http_oboe_handler_set_header(r, r->pool, &r->headers_out.headers,
                                              &hctx->xte.metadata, out_xtrace);
    if (result < 0) {
        // no logging necessary; done in helper function
        goto end;
    }


    // 4. report exit event if the body filter won't be called

    // (conditional modified from ngx_http_chunked_header_filter)
    if (r->headers_out.status == NGX_HTTP_NOT_MODIFIED
        || r->headers_out.status == NGX_HTTP_NO_CONTENT
        || r->headers_out.status == NGX_HTTP_CREATED
        || (r->method & NGX_HTTP_HEAD)) {

        result = ngx_http_oboe_filter_send_report(&hctx->md, &hctx->xte, r);
        if (result < 0) {
            goto end;
        }
        hctx->reported = 1;
    }

end:
    return ngx_http_next_header_filter(r);
}

ngx_int_t ngx_http_oboe_body_filter(ngx_http_request_t *r, ngx_chain_t *in) {
    ngx_chain_t *chain_link;
    int chain_contains_last_buffer;
    handler_ctx *hctx;
    int result;

    hctx = ngx_http_oboe_get_ctx(r);
    if (!hctx || !hctx->event_set || hctx->reported) {
        ngx_log_debug0(NGX_LOG_DEBUG_HTTP, r->connection->log, 0, "[ngx_http_oboe] no context, no event, or already reported");
        goto end;
    }

    chain_contains_last_buffer = 0;
    for (chain_link = in; chain_link != NULL; chain_link = chain_link->next) {
        if (chain_link->buf->last_buf) {
            chain_contains_last_buffer = 1;
            break;
        }
    }

    if (chain_contains_last_buffer) {
        result = ngx_http_oboe_filter_send_report(&hctx->md, &hctx->xte, r);
        if (result < 0) {
            ngx_log_error(NGX_LOG_WARN, r->connection->log, 0, "[ngx_http_oboe] reporter send failed in body filter");
            goto end;
        }
    }

end:
    return ngx_http_next_body_filter(r, in);
}
